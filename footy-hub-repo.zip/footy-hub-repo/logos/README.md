Put team logos here as PNGs named by team code, e.g. HAW.png, COL.png
