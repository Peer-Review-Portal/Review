Put each game in its own folder here, e.g. games/my-game/index.html
Then add it to ../games.json
